package padroescomportamentais.visitor;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FreteVisitorTest {

    @Test
    void deveCalcularFreteFixoDeLivro() {
        Livro livro = new Livro("Código Limpo", 90.0, "Robert Martin");
        assertEquals(5.0, livro.aceitar(new FreteVisitor()), 0.001);
    }

    @Test
    void deveCalcularFreteDeEletronicoPeloPeso() {
        Eletronico eletronico = new Eletronico("Micro-ondas", 600.0, 12.0, 127);
        assertEquals(34.0, eletronico.aceitar(new FreteVisitor()), 0.001);
    }

    @Test
    void deveCalcularFreteDeAlimentoPerecivelComRefrigeracao() {
        Alimento alimento = new Alimento("Queijo", 50.0, 2.0, true);
        assertEquals(14.0, alimento.aceitar(new FreteVisitor()), 0.001);
    }

    @Test
    void deveCalcularFreteDeAlimentoNaoPerecivelSemRefrigeracao() {
        Alimento alimento = new Alimento("Arroz", 30.0, 5.0, false);
        assertEquals(15.0, alimento.aceitar(new FreteVisitor()), 0.001);
    }

}
