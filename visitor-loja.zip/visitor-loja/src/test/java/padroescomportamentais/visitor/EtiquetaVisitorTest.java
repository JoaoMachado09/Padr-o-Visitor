package padroescomportamentais.visitor;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EtiquetaVisitorTest {

    @Test
    void deveGerarEtiquetaDeLivro() {
        Livro livro = new Livro("Padrões de Projeto", 120.0, "Gamma");
        assertEquals("Livro{nome='Padrões de Projeto', autor='Gamma', preco=120.0}",
                livro.aceitar(new EtiquetaVisitor()));
    }

    @Test
    void deveGerarEtiquetaDeEletronico() {
        Eletronico eletronico = new Eletronico("Notebook", 3000.0, 2.0, 220);
        assertEquals("Eletronico{nome='Notebook', voltagem=220V, preco=3000.0}",
                eletronico.aceitar(new EtiquetaVisitor()));
    }

    @Test
    void deveGerarEtiquetaDeAlimento() {
        Alimento alimento = new Alimento("Arroz", 30.0, 5.0, false);
        assertEquals("Alimento{nome='Arroz', perecivel=false, preco=30.0}",
                alimento.aceitar(new EtiquetaVisitor()));
    }

}
