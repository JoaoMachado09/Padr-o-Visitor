package padroescomportamentais.visitor;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ImpostoVisitorTest {

    @Test
    void deveIsentarLivroDeImposto() {
        Livro livro = new Livro("Padrões de Projeto", 120.0, "Gamma");
        assertEquals(0.0, livro.aceitar(new ImpostoVisitor()), 0.001);
    }

    @Test
    void deveCalcularImpostoDeEletronico() {
        Eletronico eletronico = new Eletronico("Notebook", 3000.0, 2.0, 220);
        assertEquals(450.0, eletronico.aceitar(new ImpostoVisitor()), 0.001);
    }

    @Test
    void deveCalcularImpostoDeAlimento() {
        Alimento alimento = new Alimento("Queijo", 50.0, 1.0, true);
        assertEquals(3.5, alimento.aceitar(new ImpostoVisitor()), 0.001);
    }

}
