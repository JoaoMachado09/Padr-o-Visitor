package padroescomportamentais.visitor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CarrinhoTest {

    private Carrinho carrinho;

    @BeforeEach
    void setUp() {
        carrinho = new Carrinho();
        carrinho.adicionar(new Livro("Padrões de Projeto", 120.0, "Gamma"));
        carrinho.adicionar(new Eletronico("Notebook", 3000.0, 2.0, 220));
        carrinho.adicionar(new Alimento("Queijo", 50.0, 2.0, true));
    }

    @Test
    void deveCalcularSubtotal() {
        assertEquals(3170.0, carrinho.calcularSubtotal(), 0.001);
    }

    @Test
    void deveSomarImpostoDeTodosOsProdutos() {
        assertEquals(453.5, carrinho.somar(new ImpostoVisitor()), 0.001);
    }

    @Test
    void deveSomarFreteDeTodosOsProdutos() {
        assertEquals(33.0, carrinho.somar(new FreteVisitor()), 0.001);
    }

    @Test
    void deveCalcularTotalComImpostoEFrete() {
        assertEquals(3656.5, carrinho.calcularTotal(), 0.001);
    }

    @Test
    void deveGerarRelatorioDeEtiquetas() {
        List<String> relatorio = carrinho.gerarRelatorio(new EtiquetaVisitor());
        assertEquals(3, relatorio.size());
        assertEquals("Livro{nome='Padrões de Projeto', autor='Gamma', preco=120.0}", relatorio.get(0));
        assertEquals("Eletronico{nome='Notebook', voltagem=220V, preco=3000.0}", relatorio.get(1));
        assertEquals("Alimento{nome='Queijo', perecivel=true, preco=50.0}", relatorio.get(2));
    }

    @Test
    void deveRetornarZeroParaCarrinhoVazio() {
        Carrinho vazio = new Carrinho();
        assertEquals(0.0, vazio.calcularTotal(), 0.001);
    }

}
