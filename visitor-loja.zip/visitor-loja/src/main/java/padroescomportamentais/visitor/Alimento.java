package padroescomportamentais.visitor;

public class Alimento implements Produto {

    private String nome;
    private double preco;
    private double pesoKg;
    private boolean perecivel;

    public Alimento(String nome, double preco, double pesoKg, boolean perecivel) {
        this.nome = nome;
        this.preco = preco;
        this.pesoKg = pesoKg;
        this.perecivel = perecivel;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public boolean isPerecivel() {
        return perecivel;
    }

    public <T> T aceitar(Visitor<T> visitor) {
        return visitor.visitarAlimento(this);
    }

}
