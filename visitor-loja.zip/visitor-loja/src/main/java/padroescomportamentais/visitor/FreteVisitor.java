package padroescomportamentais.visitor;

/**
 * Calcula o frete de cada produto:
 * livro tem frete fixo de R$ 5,00; eletrônico paga R$ 10,00 + R$ 2,00 por kg;
 * alimento paga R$ 3,00 por kg e mais R$ 8,00 de refrigeração se for perecível.
 */
public class FreteVisitor implements Visitor<Double> {

    @Override
    public Double visitarLivro(Livro livro) {
        return 5.0;
    }

    @Override
    public Double visitarEletronico(Eletronico eletronico) {
        return 10.0 + eletronico.getPesoKg() * 2.0;
    }

    @Override
    public Double visitarAlimento(Alimento alimento) {
        double frete = alimento.getPesoKg() * 3.0;
        if (alimento.isPerecivel()) {
            frete += 8.0;
        }
        return frete;
    }

}
