package padroescomportamentais.visitor;

public class Eletronico implements Produto {

    private String nome;
    private double preco;
    private double pesoKg;
    private int voltagem;

    public Eletronico(String nome, double preco, double pesoKg, int voltagem) {
        this.nome = nome;
        this.preco = preco;
        this.pesoKg = pesoKg;
        this.voltagem = voltagem;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public int getVoltagem() {
        return voltagem;
    }

    public <T> T aceitar(Visitor<T> visitor) {
        return visitor.visitarEletronico(this);
    }

}
