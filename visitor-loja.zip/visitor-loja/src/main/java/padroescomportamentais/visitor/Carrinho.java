package padroescomportamentais.visitor;

import java.util.ArrayList;
import java.util.List;

/**
 * Estrutura de objetos que percorre os produtos e aplica um visitor a cada um.
 */
public class Carrinho {

    private List<Produto> produtos = new ArrayList<>();

    public void adicionar(Produto produto) {
        this.produtos.add(produto);
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public double calcularSubtotal() {
        double subtotal = 0.0;
        for (Produto produto : produtos) {
            subtotal += produto.getPreco();
        }
        return subtotal;
    }

    public double somar(Visitor<Double> visitor) {
        double soma = 0.0;
        for (Produto produto : produtos) {
            soma += produto.aceitar(visitor);
        }
        return soma;
    }

    public List<String> gerarRelatorio(Visitor<String> visitor) {
        List<String> linhas = new ArrayList<>();
        for (Produto produto : produtos) {
            linhas.add(produto.aceitar(visitor));
        }
        return linhas;
    }

    public double calcularTotal() {
        return calcularSubtotal() + somar(new ImpostoVisitor()) + somar(new FreteVisitor());
    }

}
