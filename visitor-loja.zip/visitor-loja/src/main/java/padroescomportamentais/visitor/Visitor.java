package padroescomportamentais.visitor;

/**
 * Visitor genérico: cada operação sobre os produtos define o próprio tipo de retorno T.
 * Novas operações são adicionadas criando novos visitors, sem alterar os produtos.
 */
public interface Visitor<T> {

    T visitarLivro(Livro livro);
    T visitarEletronico(Eletronico eletronico);
    T visitarAlimento(Alimento alimento);

}
