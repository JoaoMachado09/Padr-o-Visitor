package padroescomportamentais.visitor;

/**
 * Calcula o imposto de cada produto:
 * livros são isentos, eletrônicos pagam 15% e alimentos pagam 7%.
 */
public class ImpostoVisitor implements Visitor<Double> {

    @Override
    public Double visitarLivro(Livro livro) {
        return 0.0;
    }

    @Override
    public Double visitarEletronico(Eletronico eletronico) {
        return eletronico.getPreco() * 0.15;
    }

    @Override
    public Double visitarAlimento(Alimento alimento) {
        return alimento.getPreco() * 0.07;
    }

}
