package padroescomportamentais.visitor;

public class Livro implements Produto {

    private String nome;
    private double preco;
    private String autor;

    public Livro(String nome, double preco, String autor) {
        this.nome = nome;
        this.preco = preco;
        this.autor = autor;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public String getAutor() {
        return autor;
    }

    public <T> T aceitar(Visitor<T> visitor) {
        return visitor.visitarLivro(this);
    }

}
