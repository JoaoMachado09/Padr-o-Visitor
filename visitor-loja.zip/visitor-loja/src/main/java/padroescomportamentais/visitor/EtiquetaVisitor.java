package padroescomportamentais.visitor;

/**
 * Gera o texto da etiqueta de cada produto.
 */
public class EtiquetaVisitor implements Visitor<String> {

    @Override
    public String visitarLivro(Livro livro) {
        return "Livro{nome='" + livro.getNome() + "', autor='" + livro.getAutor()
                + "', preco=" + livro.getPreco() + "}";
    }

    @Override
    public String visitarEletronico(Eletronico eletronico) {
        return "Eletronico{nome='" + eletronico.getNome() + "', voltagem=" + eletronico.getVoltagem()
                + "V, preco=" + eletronico.getPreco() + "}";
    }

    @Override
    public String visitarAlimento(Alimento alimento) {
        return "Alimento{nome='" + alimento.getNome() + "', perecivel=" + alimento.isPerecivel()
                + ", preco=" + alimento.getPreco() + "}";
    }

}
