package padroescomportamentais.visitor;

public interface Produto {

    String getNome();
    double getPreco();

    <T> T aceitar(Visitor<T> visitor);

}
