# Padrão Visitor — Loja Virtual

Aplicação em Java que evolui o exemplo do padrão comportamental **Visitor** visto em aula
(`padroescomportamentais.visitor`).

## Contexto

Um carrinho de compras guarda produtos de tipos diferentes (`Livro`, `Eletronico`, `Alimento`).
Cada operação sobre esses produtos é implementada em um visitor separado, sem alterar as classes de produto:

| Visitor | Retorno | O que faz |
|---|---|---|
| `ImpostoVisitor` | `Double` | Livro isento, eletrônico 15%, alimento 7% |
| `FreteVisitor` | `Double` | Livro R$ 5 fixo; eletrônico R$ 10 + R$ 2/kg; alimento R$ 3/kg + R$ 8 se perecível |
| `EtiquetaVisitor` | `String` | Gera a etiqueta de exibição do produto |

O `Carrinho` é a estrutura de objetos: percorre os produtos e aplica o visitor recebido
(`somar`, `gerarRelatorio`, `calcularTotal`).

## Evolução em relação ao exemplo da aula

- `Visitor<T>` é **genérico**: cada visitor define o próprio tipo de retorno (`Double` ou `String`),
  em vez de todos retornarem `String`.
- **Vários visitors** sobre a mesma hierarquia, mostrando o principal benefício do padrão:
  adicionar operações novas sem mexer nos elementos.
- Uma **estrutura de objetos** (`Carrinho`) que aplica o visitor a uma coleção heterogênea.

## Diagrama de classes

![Diagrama de classes](docs/diagrama-classes.png)

## Executar os testes

```bash
mvn test
```

Requisitos: Java 11+ e Maven. Testes com JUnit 5 (16 casos de teste).
